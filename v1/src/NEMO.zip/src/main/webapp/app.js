Application.run(function ($rootScope) {
    "use strict";
    /* perform any action on the variables within this block(on-page-load) */
    $rootScope.onAppVariablesReady = function () {
        /*
         * variables can be accessed through '$rootScope.Variables' property here
         * e.g. $rootScope.Variables.staticVariable1.getData()
         */
    };

	$rootScope.GraphqueryInvokeonResult = function(variable, data){
			
	};


	$rootScope.GraphqueryInvokeonBeforeUpdate = function(variable, data){
			
	};


	$rootScope.GraphqueryInvokeonSuccess = function(variable, data){
			
	};


	$rootScope.serviceVariable1onSuccess = function(variable, data){
			
	};

});