[Graph_Info]
name = sample
description = test network for storage service
directed = false
weighted =false
labeled = false
nodes = 6
edges = 6
addedby = admin
nodeattributes =None
edgeattributes = None
originaltype = uel
available = false
details = true
simple = false